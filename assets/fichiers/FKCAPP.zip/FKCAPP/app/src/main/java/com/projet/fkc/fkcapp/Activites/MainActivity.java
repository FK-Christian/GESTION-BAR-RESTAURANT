package com.projet.fkc.fkcapp.Activites;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import com.projet.fkc.fkcapp.R;
import com.projet.fkc.fkcapp.SMS.FKCSMS;

public class MainActivity extends Activity{

    private FKCSMS sms;
    public EditText nom,carte,tel,montant,message_send;
    public Spinner liste,formule;
    public Button lancer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fkc_layout);
        nom = (EditText) findViewById(R.id.nomC);
        carte = (EditText) findViewById(R.id.carteC);
        tel = (EditText) findViewById(R.id.telC);
        montant = (EditText) findViewById(R.id.montant);
        liste = (Spinner) findViewById(R.id.choixrequete);
        formule = (Spinner) findViewById(R.id.formuleC);
        message_send = (EditText) findViewById(R.id.messageSend);
        lancer = (Button) findViewById(R.id.run);
        montant.setEnabled(false);
        sms = new FKCSMS(this);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}

