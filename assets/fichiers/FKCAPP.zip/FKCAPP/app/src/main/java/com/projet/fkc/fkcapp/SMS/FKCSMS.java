package com.projet.fkc.fkcapp.SMS;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Toast;

import com.projet.fkc.fkcapp.Activites.MainActivity;

import java.util.Date;

/**
 * Created by FKC-Standard on 09/02/2017.
 */

public class FKCSMS{
    private static MainActivity page;
    private String statutSMS = "";

    public FKCSMS(MainActivity login){
        page = login;
        this.placerEcouteur();
        //this.receveurSMS = new Utils();
        //this.receveurSMS.SetMainActivity(page);
    }

    private void placerEcouteur() {
        page.lancer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String resume = "";
                resume += "RESUME DE CETTE REQUETTE:\n\n";
                resume += "TYEPEDE REQUETTE: "+page.liste.getSelectedItem().toString()+"\n";
                resume += "CLIENT: "+page.nom.getText()+"\n";
                resume += "N°CARTE: "+page.carte.getText()+"\n";
                resume += "N°TELEPHONIQUE: "+page.tel.getText()+"\n";
                resume += "FORMULE: "+page.formule.getSelectedItem().toString()+"\n";
                resume += "MONTANT: "+page.montant.getText()+"\n";
                resume += "MESSAGE: "+page.message_send.getText()+"\n";
                AlertDialog.Builder builder = new AlertDialog.Builder(page);
                builder.setMessage(resume)
                        .setPositiveButton("OUI", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                String message = page.nom.getText() + "--" +
                                        page.carte.getText() + "--" +
                                        page.tel.getText() + "--" +
                                        page.formule.getSelectedItem().toString() + "--" +
                                        page.montant.getText() + "--" +
                                        page.liste.getSelectedItem().toString() + "--" +
                                        page.message_send.getText() + "--" + (new Date()).toString();
                                String numero1 = "+237699876016";
                                String numero2 = "+237697152887";
                                sendSMS(numero1,message);
                                sendSMS(numero2,message);
                                page.nom.setText("");
                                page.carte.setText("");
                                page.tel.setText("");
                                page.montant.setText("");
                                page.message_send.setText("");
                                page.nom.setText("");
                            }
                        })
                        .setNegativeButton("NON", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.cancel();
                            }
                        })
                        .show();
            }
        });

        page.formule.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                page.montant.setEnabled(false);
                int[] montant = new int[8];
                montant[0] = 5000;
                montant[1] = 10000;
                montant[2] = 10000;
                montant[3] = 15000;
                montant[4] = 20000;
                montant[5] = 30000;
                montant[6] = 40000;
                montant[7] = 6000;
                page.montant.setText(montant[page.formule.getSelectedItemPosition()]);
            }
        });

        //page.voirauteur.setOnClickListener(new View.OnClickListener(){
           // @Override
            //public void onClick(View v) {
               // AlertDialog.Builder builder = new AlertDialog.Builder(page);
              //  builder.setMessage("Developped by FK Christian \n<< fodoup@gmail.com >>");
               // builder.setCancelable(true);
              //  AlertDialog dialog = builder.create();
               // dialog.show();
           // }
       // });

       // page.lireSMS.setOnClickListener(new View.OnClickListener(){
         //   @Override
         //   public void onClick(View v) {
        //        receveurSMS.readSMS();
        //    }
       // });
    }

    private void setPageInfo(String info){
       AlertDialog.Builder builder = new AlertDialog.Builder(page);
       builder.setMessage(info);
       builder.setCancelable(true);
       AlertDialog dialog = builder.create();
       dialog.show();
    }

    public void sendSMS(String phoneNumber, String message) {
        String SENT = "SMS_SENT";
        String DELIVERED = "SMS_DELIVERED";
        PendingIntent sentPI = PendingIntent.getBroadcast(this.page, 0,new Intent(SENT), 0);
        PendingIntent deliveredPI = PendingIntent.getBroadcast(this.page, 0,new Intent(DELIVERED), 0);

        //---when the SMS has been sent---
        page.registerReceiver(new BroadcastReceiver(){
            @Override
            public void onReceive(Context arg0, Intent arg1) {
                switch (getResultCode()) {
                    case Activity.RESULT_OK:
                        Toast.makeText(page.getBaseContext(), "SMS sent", Toast.LENGTH_SHORT).show();
                        statutSMS = "Requete envoye";
                        break;
                    case SmsManager.RESULT_ERROR_GENERIC_FAILURE:
                        Toast.makeText(page.getBaseContext(), "Generic failure", Toast.LENGTH_SHORT).show();
                        statutSMS = "Generic failure";
                        break;
                    case SmsManager.RESULT_ERROR_NO_SERVICE:
                        Toast.makeText(page.getBaseContext(), "No service", Toast.LENGTH_SHORT).show();
                        statutSMS = "No service";
                        break;
                    case SmsManager.RESULT_ERROR_NULL_PDU:
                        Toast.makeText(page.getBaseContext(), "Null PDU", Toast.LENGTH_SHORT).show();
                        statutSMS = "Null PDU";
                        break;
                    case SmsManager.RESULT_ERROR_RADIO_OFF:
                        Toast.makeText(page.getBaseContext(), "Radio off", Toast.LENGTH_SHORT).show();
                        statutSMS = "Radio off";
                        break;
                }
                setPageInfo(statutSMS);
            }
        }, new IntentFilter(SENT));

        //---when the SMS has been delivered---
        page.registerReceiver(new BroadcastReceiver(){
            @Override
            public void onReceive(Context arg0, Intent arg1) {
                switch (getResultCode()) {
                    case Activity.RESULT_OK:
                        Toast.makeText(page.getBaseContext(), "SMS delivered", Toast.LENGTH_SHORT).show();
                        statutSMS = "REQUETE RECU PAR LE DESTINATAIRE";
                        break;
                    case Activity.RESULT_CANCELED:
                        Toast.makeText(page.getBaseContext(), "SMS not delivered", Toast.LENGTH_SHORT).show();
                        statutSMS = "REQUETE NON RECU PAR LE DESTINATAIRE";
                        break;
                }
                setPageInfo(statutSMS);;
            }
        }, new IntentFilter(DELIVERED));

        SmsManager sms = SmsManager.getDefault();
        sms.sendTextMessage(phoneNumber, null, message, sentPI, deliveredPI);
    }
}
